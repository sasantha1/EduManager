-- Create admin user for initial login
INSERT INTO users (name, email, password, role, status, created_at, updated_at)
VALUES ('Admin User', 'admin@example.com', '$2a$10$yfIHMg3xrCZYqAL4pCdOYOQgpJ.N9xPLe8MbQBqWNBp/GKFXx.bAe', 'ADMIN', 'ACTIVE', NOW(), NOW())
ON DUPLICATE KEY UPDATE email = email;
-- Note: The password is 'admin123' encrypted with BCrypt

-- Create sample teacher
INSERT INTO users (name, email, password, role, status, created_at, updated_at)
VALUES ('John Smith', 'teacher@example.com', '$2a$10$yfIHMg3xrCZYqAL4pCdOYOQgpJ.N9xPLe8MbQBqWNBp/GKFXx.bAe', 'TEACHER', 'ACTIVE', NOW(), NOW())
ON DUPLICATE KEY UPDATE email = email;

INSERT INTO teachers (id, teacher_id, department)
SELECT id, 'T1001', 'Computer Science' FROM users WHERE email = 'teacher@example.com'
ON DUPLICATE KEY UPDATE teacher_id = teacher_id;

-- Create sample student
INSERT INTO users (name, email, password, role, status, created_at, updated_at)
VALUES ('Jane Doe', 'student@example.com', '$2a$10$yfIHMg3xrCZYqAL4pCdOYOQgpJ.N9xPLe8MbQBqWNBp/GKFXx.bAe', 'STUDENT', 'ACTIVE', NOW(), NOW())
ON DUPLICATE KEY UPDATE email = email;

INSERT INTO students (id, student_id, program, year)
SELECT id, 'S1001', 'Computer Science', '2nd Year' FROM users WHERE email = 'student@example.com'
ON DUPLICATE KEY UPDATE student_id = student_id;

-- Create sample course
INSERT INTO courses (name, code, description, teacher_id, created_at, updated_at)
SELECT 'Introduction to Programming', 'CS101', 'A beginner-friendly introduction to programming concepts using Java.', 
       (SELECT id FROM teachers WHERE teacher_id = 'T1001'), NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE code = 'CS101');

-- Create sample schedule
INSERT INTO schedules (course_id, day, start_time, end_time, room)
SELECT id, 'MONDAY', '10:00:00', '12:00:00', 'Room A101' 
FROM courses WHERE code = 'CS101'
AND NOT EXISTS (SELECT 1 FROM schedules WHERE course_id = (SELECT id FROM courses WHERE code = 'CS101') AND day = 'MONDAY');

-- Enroll student in course
INSERT INTO student_courses (student_id, course_id)
SELECT 
    (SELECT id FROM students WHERE student_id = 'S1001'),
    (SELECT id FROM courses WHERE code = 'CS101')
WHERE NOT EXISTS (
    SELECT 1 FROM student_courses 
    WHERE student_id = (SELECT id FROM students WHERE student_id = 'S1001')
    AND course_id = (SELECT id FROM courses WHERE code = 'CS101')
);

-- Create sample assignment
INSERT INTO assignments (course_id, title, description, due_date, total_points, created_at, updated_at)
SELECT 
    id, 
    'Java Basics Assignment', 
    'Create a simple Java program that demonstrates variables, loops, and conditional statements.', 
    DATE_ADD(NOW(), INTERVAL 7 DAY), 
    100, 
    NOW(), 
    NOW()
FROM courses WHERE code = 'CS101'
AND NOT EXISTS (SELECT 1 FROM assignments WHERE title = 'Java Basics Assignment' AND course_id = (SELECT id FROM courses WHERE code = 'CS101'));
