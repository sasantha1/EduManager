package com.sms.service;

import com.sms.dto.AssignmentDTO;
import com.sms.dto.CourseDTO;
import com.sms.dto.request.AssignmentRequest;
import com.sms.model.Assignment;
import com.sms.model.Course;
import com.sms.repository.AssignmentRepository;
import com.sms.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AssignmentService {
    
    @Autowired
    private AssignmentRepository assignmentRepository;
    
    @Autowired
    private CourseRepository courseRepository;
    
    @Transactional
    public AssignmentDTO createAssignment(AssignmentRequest request) {
        Course course = courseRepository.findById(request.getCourseId())
            .orElseThrow(() -> new RuntimeException("Course not found with id: " + request.getCourseId()));
        
        Assignment assignment = new Assignment();
        assignment.setTitle(request.getTitle());
        assignment.setDescription(request.getDescription());
        assignment.setDueDate(request.getDueDate());
        assignment.setTotalPoints(request.getTotalPoints());
        assignment.setCourse(course);
        
        return convertToDTO(assignmentRepository.save(assignment));
    }
    
    public List<AssignmentDTO> getAllAssignments() {
        return assignmentRepository.findAll().stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }
    
    public Optional<AssignmentDTO> getAssignmentById(Long id) {
        return assignmentRepository.findById(id)
            .map(this::convertToDTO);
    }
    
    public List<AssignmentDTO> getAssignmentsByCourse(Long courseId) {
        Course course = courseRepository.findById(courseId)
            .orElseThrow(() -> new RuntimeException("Course not found with id: " + courseId));
        
        return assignmentRepository.findByCourse(course).stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }
    
    @Transactional
    public AssignmentDTO updateAssignment(Long id, AssignmentRequest request) {
        Assignment assignment = assignmentRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Assignment not found with id: " + id));
        
        Course course = courseRepository.findById(request.getCourseId())
            .orElseThrow(() -> new RuntimeException("Course not found with id: " + request.getCourseId()));
        
        assignment.setTitle(request.getTitle());
        assignment.setDescription(request.getDescription());
        assignment.setDueDate(request.getDueDate());
        assignment.setTotalPoints(request.getTotalPoints());
        assignment.setCourse(course);
        
        return convertToDTO(assignmentRepository.save(assignment));
    }
    
    @Transactional
    public void deleteAssignment(Long id) {
        Assignment assignment = assignmentRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Assignment not found with id: " + id));
        
        assignmentRepository.delete(assignment);
    }
    
    private AssignmentDTO convertToDTO(Assignment assignment) {
        AssignmentDTO dto = new AssignmentDTO();
        dto.setId(assignment.getId());
        dto.setTitle(assignment.getTitle());
        dto.setDescription(assignment.getDescription());
        dto.setDueDate(assignment.getDueDate());
        dto.setTotalPoints(assignment.getTotalPoints());
        dto.setCreatedAt(assignment.getCreatedAt());
        dto.setUpdatedAt(assignment.getUpdatedAt());
        
        // Set course without full details to avoid circular references
        CourseDTO courseDTO = new CourseDTO();
        courseDTO.setId(assignment.getCourse().getId());
        courseDTO.setName(assignment.getCourse().getName());
        courseDTO.setCode(assignment.getCourse().getCode());
        dto.setCourse(courseDTO);
        
        return dto;
    }
}
