package com.sms.service;

import com.sms.dto.AssignmentDTO;
import com.sms.dto.StudentDTO;
import com.sms.dto.SubmissionDTO;
import com.sms.dto.request.GradeSubmissionRequest;
import com.sms.dto.request.SubmissionRequest;
import com.sms.model.Assignment;
import com.sms.model.Student;
import com.sms.model.Submission;
import com.sms.repository.AssignmentRepository;
import com.sms.repository.StudentRepository;
import com.sms.repository.SubmissionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class SubmissionService {
    
    @Autowired
    private SubmissionRepository submissionRepository;
    
    @Autowired
    private AssignmentRepository assignmentRepository;
    
    @Autowired
    private StudentRepository studentRepository;
    
    @Transactional
    public SubmissionDTO submitAssignment(SubmissionRequest request, Long studentId) {
        Assignment assignment = assignmentRepository.findById(request.getAssignmentId())
            .orElseThrow(() -> new RuntimeException("Assignment not found with id: " + request.getAssignmentId()));
        
        Student student = studentRepository.findById(studentId)
            .orElseThrow(() -> new RuntimeException("Student not found with id: " + studentId));
        
        // Check if student is enrolled in the course
        boolean isEnrolled = student.getEnrolledCourses().stream()
            .anyMatch(course -> course.getId().equals(assignment.getCourse().getId()));
        
        if (!isEnrolled) {
            throw new RuntimeException("Student is not enrolled in this course");
        }
        
        // Check if submission already exists
        Optional<Submission> existingSubmission = submissionRepository.findByAssignmentAndStudent(assignment, student);
        
        Submission submission;
        if (existingSubmission.isPresent()) {
            submission = existingSubmission.get();
            submission.setFilePath(request.getFilePath());
            submission.setSubmissionDate(LocalDateTime.now());
        } else {
            submission = new Submission();
            submission.setAssignment(assignment);
            submission.setStudent(student);
            submission.setFilePath(request.getFilePath());
            submission.setSubmissionDate(LocalDateTime.now());
        }
        
        return convertToDTO(submissionRepository.save(submission));
    }
    
    public List<SubmissionDTO> getSubmissionsByAssignment(Long assignmentId) {
        Assignment assignment = assignmentRepository.findById(assignmentId)
            .orElseThrow(() -> new RuntimeException("Assignment not found with id: " + assignmentId));
        
        return submissionRepository.findByAssignment(assignment).stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }
    
    public List<SubmissionDTO> getSubmissionsByStudent(Long studentId) {
        Student student = studentRepository.findById(studentId)
            .orElseThrow(() -> new RuntimeException("Student not found with id: " + studentId));
        
        return submissionRepository.findByStudent(student).stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }
    
    public Optional<SubmissionDTO> getSubmissionById(Long id) {
        return submissionRepository.findById(id)
            .map(this::convertToDTO);
    }
    
    @Transactional
    public SubmissionDTO gradeSubmission(Long id, GradeSubmissionRequest request) {
        Submission submission = submissionRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Submission not found with id: " + id));
        
        submission.setGrade(request.getGrade());
        submission.setFeedback(request.getFeedback());
        
        return convertToDTO(submissionRepository.save(submission));
    }
    
    private SubmissionDTO convertToDTO(Submission submission) {
        SubmissionDTO dto = new SubmissionDTO();
        dto.setId(submission.getId());
        dto.setSubmissionDate(submission.getSubmissionDate());
        dto.setFilePath(submission.getFilePath());
        dto.setGrade(submission.getGrade());
        dto.setFeedback(submission.getFeedback());
        dto.setCreatedAt(submission.getCreatedAt());
        dto.setUpdatedAt(submission.getUpdatedAt());
        
        // Set assignment with minimal details
        AssignmentDTO assignmentDTO = new AssignmentDTO();
        assignmentDTO.setId(submission.getAssignment().getId());
        assignmentDTO.setTitle(submission.getAssignment().getTitle());
        assignmentDTO.setDueDate(submission.getAssignment().getDueDate());
        assignmentDTO.setTotalPoints(submission.getAssignment().getTotalPoints());
        dto.setAssignment(assignmentDTO);
        
        // Set student with minimal details
        StudentDTO studentDTO = new StudentDTO();
        studentDTO.setId(submission.getStudent().getId());
        studentDTO.setName(submission.getStudent().getName());
        studentDTO.setStudentId(submission.getStudent().getStudentId());
        dto.setStudent(studentDTO);
        
        return dto;
    }
}
