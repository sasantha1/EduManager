package com.sms.service;

import com.sms.model.Course;
import com.sms.model.Student;
import com.sms.repository.CourseRepository;
import com.sms.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class EnrollmentService {
    
    @Autowired
    private StudentRepository studentRepository;
    
    @Autowired
    private CourseRepository courseRepository;
    
    @Transactional
    public void enrollStudentInCourse(Long studentId, Long courseId) {
        Student student = studentRepository.findById(studentId)
            .orElseThrow(() -> new RuntimeException("Student not found with id: " + studentId));
        
        Course course = courseRepository.findById(courseId)
            .orElseThrow(() -> new RuntimeException("Course not found with id: " + courseId));
        
        // Check if already enrolled
        if (student.getEnrolledCourses().contains(course)) {
            throw new RuntimeException("Student is already enrolled in this course");
        }
        
        student.getEnrolledCourses().add(course);
        course.getStudents().add(student);
        
        studentRepository.save(student);
    }
    
    @Transactional
    public void unenrollStudentFromCourse(Long studentId, Long courseId) {
        Student student = studentRepository.findById(studentId)
            .orElseThrow(() -> new RuntimeException("Student not found with id: " + studentId));
        
        Course course = courseRepository.findById(courseId)
            .orElseThrow(() -> new RuntimeException("Course not found with id: " + courseId));
        
        // Check if enrolled
        if (!student.getEnrolledCourses().contains(course)) {
            throw new RuntimeException("Student is not enrolled in this course");
        }
        
        student.getEnrolledCourses().remove(course);
        course.getStudents().remove(student);
        
        studentRepository.save(student);
    }
}
