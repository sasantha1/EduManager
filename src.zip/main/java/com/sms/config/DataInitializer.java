package com.sms.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;

import javax.sql.DataSource;

@Configuration
public class DataInitializer {

    @Autowired
    private DataSource dataSource;

    @Bean
    public CommandLineRunner initData() {
        return args -> {
            try {
                // First run schema.sql to create tables
                ResourceDatabasePopulator schemaPopulator = new ResourceDatabasePopulator();
                schemaPopulator.addScript(new ClassPathResource("db/schema.sql"));
                schemaPopulator.execute(dataSource);
                
                // Then run data.sql to populate initial data
                ResourceDatabasePopulator dataPopulator = new ResourceDatabasePopulator();
                dataPopulator.addScript(new ClassPathResource("db/data.sql"));
                dataPopulator.execute(dataSource);
                
                System.out.println("Database initialized successfully!");
            } catch (Exception e) {
                System.err.println("Error initializing database: " + e.getMessage());
                e.printStackTrace();
            }
        };
    }
}
