package com.sms.controller;

import com.sms.dto.SubmissionDTO;
import com.sms.dto.request.SubmissionRequest;
import com.sms.dto.request.GradeSubmissionRequest;
import com.sms.dto.response.ApiResponse;
import com.sms.security.UserDetailsImpl;
import com.sms.service.SubmissionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/submissions")
@CrossOrigin(origins = "*", maxAge = 3600)
public class SubmissionController {
    
    @Autowired
    private SubmissionService submissionService;
    
    @PostMapping
    @PreAuthorize("hasRole('STUDENT')")
    public ResponseEntity<?> submitAssignment(
            @Valid @RequestBody SubmissionRequest request,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        try {
            SubmissionDTO submission = submissionService.submitAssignment(request, userDetails.getId());
            return ResponseEntity.ok(ApiResponse.success("Assignment submitted successfully", submission));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @GetMapping("/assignment/{assignmentId}")
    @PreAuthorize("hasRole('TEACHER') or hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<SubmissionDTO>>> getSubmissionsByAssignment(@PathVariable Long assignmentId) {
        List<SubmissionDTO> submissions = submissionService.getSubmissionsByAssignment(assignmentId);
        return ResponseEntity.ok(ApiResponse.success("Submissions retrieved successfully", submissions));
    }
    
    @GetMapping("/student/{studentId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('TEACHER') or (hasRole('STUDENT') and #studentId == authentication.principal.id)")
    public ResponseEntity<ApiResponse<List<SubmissionDTO>>> getSubmissionsByStudent(@PathVariable Long studentId) {
        List<SubmissionDTO> submissions = submissionService.getSubmissionsByStudent(studentId);
        return ResponseEntity.ok(ApiResponse.success("Submissions retrieved successfully", submissions));
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<?> getSubmissionById(@PathVariable Long id) {
        return submissionService.getSubmissionById(id)
            .map(submission -> ResponseEntity.ok(ApiResponse.success("Submission retrieved successfully", submission)))
            .orElse(ResponseEntity.notFound().build());
    }
    
    @PutMapping("/{id}/grade")
    @PreAuthorize("hasRole('TEACHER') or hasRole('ADMIN')")
    public ResponseEntity<?> gradeSubmission(@PathVariable Long id, @Valid @RequestBody GradeSubmissionRequest request) {
        try {
            SubmissionDTO gradedSubmission = submissionService.gradeSubmission(id, request);
            return ResponseEntity.ok(ApiResponse.success("Submission graded successfully", gradedSubmission));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }
}
