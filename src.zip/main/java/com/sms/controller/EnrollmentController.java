package com.sms.controller;

import com.sms.dto.response.ApiResponse;
import com.sms.security.UserDetailsImpl;
import com.sms.service.EnrollmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/enrollments")
@CrossOrigin(origins = "*", maxAge = 3600)
public class EnrollmentController {
    
    @Autowired
    private EnrollmentService enrollmentService;
    
    @PostMapping("/enroll/{courseId}")
    @PreAuthorize("hasRole('STUDENT')")
    public ResponseEntity<?> enrollInCourse(
            @PathVariable Long courseId,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        try {
            enrollmentService.enrollStudentInCourse(userDetails.getId(), courseId);
            return ResponseEntity.ok(ApiResponse.success("Successfully enrolled in course", null));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @PostMapping("/unenroll/{courseId}")
    @PreAuthorize("hasRole('STUDENT')")
    public ResponseEntity<?> unenrollFromCourse(
            @PathVariable Long courseId,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        try {
            enrollmentService.unenrollStudentFromCourse(userDetails.getId(), courseId);
            return ResponseEntity.ok(ApiResponse.success("Successfully unenrolled from course", null));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @PostMapping("/admin/enroll")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> adminEnrollStudent(
            @RequestParam Long studentId,
            @RequestParam Long courseId) {
        try {
            enrollmentService.enrollStudentInCourse(studentId, courseId);
            return ResponseEntity.ok(ApiResponse.success("Student successfully enrolled in course", null));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @PostMapping("/admin/unenroll")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> adminUnenrollStudent(
            @RequestParam Long studentId,
            @RequestParam Long courseId) {
        try {
            enrollmentService.unenrollStudentFromCourse(studentId, courseId);
            return ResponseEntity.ok(ApiResponse.success("Student successfully unenrolled from course", null));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }
}
