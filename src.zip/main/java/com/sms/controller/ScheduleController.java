package com.sms.controller;

import com.sms.dto.ScheduleDTO;
import com.sms.dto.request.ScheduleRequest;
import com.sms.dto.response.ApiResponse;
import com.sms.service.ScheduleService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/schedules")
@CrossOrigin(origins = "*", maxAge = 3600)
public class ScheduleController {
    
    @Autowired
    private ScheduleService scheduleService;
    
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> createSchedule(@Valid @RequestBody ScheduleRequest request) {
        try {
            ScheduleDTO createdSchedule = scheduleService.createSchedule(request);
            return ResponseEntity.ok(ApiResponse.success("Schedule created successfully", createdSchedule));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @GetMapping("/course/{courseId}")
    public ResponseEntity<ApiResponse<List<ScheduleDTO>>> getSchedulesByCourse(@PathVariable Long courseId) {
        List<ScheduleDTO> schedules = scheduleService.getSchedulesByCourse(courseId);
        return ResponseEntity.ok(ApiResponse.success("Schedules retrieved successfully", schedules));
    }
    
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> updateSchedule(@PathVariable Long id, @Valid @RequestBody ScheduleRequest request) {
        try {
            ScheduleDTO updatedSchedule = scheduleService.updateSchedule(id, request);
            return ResponseEntity.ok(ApiResponse.success("Schedule updated successfully", updatedSchedule));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteSchedule(@PathVariable Long id) {
        try {
            scheduleService.deleteSchedule(id);
            return ResponseEntity.ok(ApiResponse.success("Schedule deleted successfully", null));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }
}
